const express = require("express");
const app = express();
const path = require('path');
const UserModel = require("./config/database");
const bcrypt = require("bcrypt");
const session = require('express-session');
const MongoStore= require('connect-mongo');
const passport = require("passport");
require("./config/passport");

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'view')); 

app.use(express.urlencoded({extended:true}));



app.use(session({
    secret :"keyboard cat",
    resave :false,
    saveUninitialized:true,
    store :MongoStore.create({mongoUrl : "mongodb://localhost:27017/passport" , collectionName:"sessions"}),
    cookie:{
        maxAge:1000*60*60*24
    }
}))


app.use(passport.initialize());
app.use(passport.session());



app.get('/login', (req, res) => {
    res.render("login"); 
});

app.get('/register', (req, res) => {
    res.render("register");
});

app.post('/login',passport.authenticate('local',{successRedirect:'/protected'}) );


app.post('/register', async(req, res) => {
    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    let user = new UserModel({
        username: req.body.username,
       password :hashedPassword
    })
    user.save().then(user=>console.log(user));
    res.send({success : true })
});

app.get('/logout', (req, res, next) => {
    req.logout(function(err) {
      if (err) { return next(err); }
      res.redirect('/login'); 
    });
  });
app.get('/protected', (req, res) => {
    if(req.isAuthenticated())
    {res.send("Protected"); }
    else
    {
        res.status(400).json({msg : "unauthorized user"})
    }
    });

app.listen(5000, () => {
    console.log("listening to port 5000");
});
